function BlogHeroSections() {
  return <div>BlogHeroSection</div>;
}

export default BlogHeroSections;
